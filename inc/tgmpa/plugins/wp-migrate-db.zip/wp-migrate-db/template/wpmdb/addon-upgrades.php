<div class="option-section disabled">
	<label class="media-files force-disabled checkbox-label upgrade-pro">
		<input type="checkbox" value="1" data-available="" disabled="disabled" />
		<span class="option-row"><?php _e( 'Media Files', 'wp-migrate-db-pro-media-files' ); ?></span><span class="option-description"><a href="https://deliciousbrains.com/wp-migrate-db-pro/upgrade/?utm_campaign=WP%2BMigrate%2BDB%2BPro%2BUpgrade&utm_source=MDB%2BFree&utm_medium=insideplugin&utm_content=upgrade-media-files" target="_blank"><?php _e( 'Upgrade to Pro', 'wp-migrate-db' ); ?></a> <?php _e( 'to push and pull media files', 'wp-migrate-db' ); ?></span>
	</label>
</div>
<div class="option-section disabled">
	<label class="force-disabled checkbox-label upgrade-pro">
		<input type="checkbox" disabled="disabled" />
		<span class="option-row"><?php _e( 'Theme Files', 'wp-migrate-db-pro' ); ?></span><span class="option-description"><a href="https://deliciousbrains.com/wp-migrate-db-pro/upgrade/?utm_campaign=WP%2BMigrate%2BDB%2BPro%2BUpgrade&utm_source=MDB%2BFree&utm_medium=insideplugin&utm_content=upgrade-theme-files" target="_blank"><?php _e( 'Upgrade to Pro', 'wp-migrate-db' ); ?></a> <?php _e( 'to push and pull theme files', 'wp-migrate-db' ); ?></span>
	</label>
</div>

<div class="option-section disabled">
	<label class="force-disabled checkbox-label upgrade-pro">
		<input type="checkbox" disabled="disabled" />
		<span class="option-row"><?php _e( 'Plugin Files', 'wp-migrate-db' ); ?></span><span class="option-description"><a href="https://deliciousbrains.com/wp-migrate-db-pro/upgrade/?utm_campaign=WP%2BMigrate%2BDB%2BPro%2BUpgrade&utm_source=MDB%2BFree&utm_medium=insideplugin&utm_content=upgrade-plugin-files" target="_blank"><?php _e( 'Upgrade to Pro', 'wp-migrate-db' ); ?></a> <?php _e( 'to push and pull plugin files', 'wp-migrate-db' ); ?></span>
	</label>

</div>
